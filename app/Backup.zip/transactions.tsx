import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useState } from "react";
import { Alert, Modal, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useExpenses } from "../context/ExpenseContext";

export default function TransactionsScreen() {
  const router = useRouter();
  const { state, deleteExpense, updateExpense } = useExpenses();
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  
  // Edit form state
  const [editTitle, setEditTitle] = useState("");
  const [editAmount, setEditAmount] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [editDate, setEditDate] = useState("");
  const [editPayment, setEditPayment] = useState("");
  
  // Sort expenses by date (newest first)
  const sortedExpenses = [...state.expenses].sort((a, b) => {
    const dateA = new Date(a.date || Date.now());
    const dateB = new Date(b.date || Date.now());
    return dateB.getTime() - dateA.getTime();
  });

  // Get category icon
  const getCategoryIcon = (category: string) => {
    const icons: any = {
      Food: "🍔",
      Transport: "🚗",
      Bills: "💡",
      Shopping: "🛒",
      Others: "📦",
    };
    return icons[category] || "📦";
  };

  // Get payment method (simulated)
  const getPaymentMethod = (index: number) => {
    const methods = ["UPI", "Credit Card", "Debit Card", "Cash", "Net Banking"];
    return methods[index % methods.length];
  };

  // Format date nicely
  const formatDate = (dateStr: string | undefined) => {
    if (!dateStr) return "Today";
    const date = new Date(dateStr);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  // Available categories
  const categories = ["Food", "Transport", "Bills", "Shopping", "Others"];
  
  // Available payment methods
  const paymentMethods = ["UPI", "Credit Card", "Debit Card", "Cash", "Net Banking"];

  // Handle delete
  const handleDelete = (id: string) => {
    Alert.alert(
      "Delete Transaction",
      "Are you sure you want to delete this transaction?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Delete", 
          style: "destructive",
          onPress: async () => {
            await deleteExpense(id);
            setSelectedTransaction(null);
          }
        },
      ]
    );
  };

  // Handle edit - initialize all fields
  const handleEdit = () => {
    if (selectedTransaction) {
      setEditTitle(selectedTransaction.title || "");
      setEditAmount(selectedTransaction.amount.toString());
      setEditCategory(selectedTransaction.category || "Food");
      setEditDate(selectedTransaction.date || "");
      setEditPayment(selectedTransaction.payment || "UPI");
      setIsEditing(true);
    }
  };

  // Save edited transaction
  const saveEdit = async () => {
    if (selectedTransaction) {
      const updatedExpense = {
        ...selectedTransaction,
        title: editTitle || selectedTransaction.title,
        amount: parseFloat(editAmount) || selectedTransaction.amount,
        category: editCategory || selectedTransaction.category,
        date: editDate || selectedTransaction.date,
        payment: editPayment || selectedTransaction.payment,
      };
      await updateExpense(updatedExpense);
      setIsEditing(false);
      setSelectedTransaction(updatedExpense);
    }
  };

  // Render category selector
  const renderCategorySelector = () => (
    <View style={styles.categorySelector}>
      {categories.map((cat) => (
        <TouchableOpacity
          key={cat}
          style={[
            styles.categoryOption,
            editCategory === cat && styles.categoryOptionSelected
          ]}
          onPress={() => setEditCategory(cat)}
        >
          <Text style={styles.categoryIcon}>{getCategoryIcon(cat)}</Text>
          <Text style={[
            styles.categoryOptionText,
            editCategory === cat && styles.categoryOptionTextSelected
          ]}>{cat}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  // Render payment method selector
  const renderPaymentSelector = () => (
    <View style={styles.categorySelector}>
      {paymentMethods.map((method) => (
        <TouchableOpacity
          key={method}
          style={[
            styles.categoryOption,
            editPayment === method && styles.categoryOptionSelected
          ]}
          onPress={() => setEditPayment(method)}
        >
          <Text style={[
            styles.categoryOptionText,
            editPayment === method && styles.categoryOptionTextSelected
          ]}>{method}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={["#5f2eea", "#7b3fe4", "#8e44ff"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>All Transactions</Text>
        <View style={{ width: 40 }} />
      </LinearGradient>

      {/* Transaction List */}
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {sortedExpenses.map((item: any, index: number) => (
          <TouchableOpacity 
            key={index}
            style={styles.transactionItem}
            onPress={() => setSelectedTransaction(item)}
            activeOpacity={0.7}
          >
            <View style={styles.iconCircle}>
              <Text style={{ fontSize: 22 }}>{getCategoryIcon(item.category)}</Text>
            </View>

            <View style={styles.transactionInfo}>
              <Text style={styles.transactionName}>
                {item.title || item.description || `${item.category} Expense`}
              </Text>
              <View style={styles.metaRow}>
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryText}>{item.category}</Text>
                </View>
                <Text style={styles.dateText}>{formatDate(item.date)}</Text>
              </View>
            </View>

            <View style={styles.amountContainer}>
              <Text style={styles.amountText}>-₹{item.amount}</Text>
              <Text style={styles.paymentMethod}>{item.payment || getPaymentMethod(index)}</Text>
            </View>
          </TouchableOpacity>
        ))}

        {sortedExpenses.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>📭</Text>
            <Text style={styles.emptyText}>No transactions yet</Text>
            <Text style={styles.emptySubtext}>Add your first expense to see it here</Text>
          </View>
        )}
      </ScrollView>

      {/* Transaction Details Modal */}
      <Modal
        visible={selectedTransaction !== null && !isEditing}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setSelectedTransaction(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {selectedTransaction && (
              <>
                <View style={styles.modalHeader}>
                  <View style={[styles.modalIconCircle, { backgroundColor: "#f2f2f5" }]}>
                    <Text style={{ fontSize: 36 }}>{getCategoryIcon(selectedTransaction.category)}</Text>
                  </View>
                  <TouchableOpacity 
                    style={styles.closeButton}
                    onPress={() => setSelectedTransaction(null)}
                  >
                    <Ionicons name="close" size={24} color="#555" />
                  </TouchableOpacity>
                </View>

                <Text style={styles.modalTitle}>
                  {selectedTransaction.title || selectedTransaction.description || `${selectedTransaction.category} Expense`}
                </Text>
                
                <Text style={styles.modalAmount}>-₹{selectedTransaction.amount}</Text>

                <View style={styles.detailSection}>
                  <Text style={styles.detailTitle}>Transaction Details</Text>
                  
                  <View style={styles.detailRow}>
                    <View style={styles.detailItem}>
                      <Text style={styles.detailLabel}>Category</Text>
                      <Text style={styles.detailValue}>{selectedTransaction.category}</Text>
                    </View>
                    <View style={styles.detailItem}>
                      <Text style={styles.detailLabel}>Date</Text>
                      <Text style={styles.detailValue}>{formatDate(selectedTransaction.date)}</Text>
                    </View>
                  </View>

                  <View style={styles.detailRow}>
                    <View style={styles.detailItem}>
                      <Text style={styles.detailLabel}>Payment Method</Text>
                      <Text style={styles.detailValue}>{selectedTransaction.payment || getPaymentMethod(state.expenses.indexOf(selectedTransaction))}</Text>
                    </View>
                    <View style={styles.detailItem}>
                      <Text style={styles.detailLabel}>Status</Text>
                      <Text style={[styles.detailValue, { color: "#22c55e" }]}>Completed</Text>
                    </View>
                  </View>

                  {selectedTransaction.date && (
                    <View style={styles.detailRow}>
                      <View style={styles.detailItemFull}>
                        <Text style={styles.detailLabel}>Full Date</Text>
                        <Text style={styles.detailValue}>
                          {new Date(selectedTransaction.date).toLocaleDateString('en-US', { 
                            weekday: 'long',
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}
                        </Text>
                      </View>
                    </View>
                  )}
                </View>

                {/* Action Buttons */}
                <View style={styles.actionButtons}>
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.editButton]}
                    onPress={handleEdit}
                  >
                    <Ionicons name="pencil" size={20} color="#fff" />
                    <Text style={styles.actionButtonText}>Edit</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={[styles.actionButton, styles.deleteButton]}
                    onPress={() => handleDelete(selectedTransaction.id)}
                  >
                    <Ionicons name="trash" size={20} color="#fff" />
                    <Text style={styles.actionButtonText}>Delete</Text>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity 
                  style={styles.doneButton}
                  onPress={() => setSelectedTransaction(null)}
                >
                  <Text style={styles.doneButtonText}>Done</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Edit Modal */}
      <Modal
        visible={isEditing}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsEditing(false)}
      >
        <View style={styles.modalOverlay}>
          <ScrollView style={styles.editScrollView}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.editModalTitle}>Edit Transaction</Text>
                <TouchableOpacity 
                  style={styles.closeButton}
                  onPress={() => setIsEditing(false)}
                >
                  <Ionicons name="close" size={24} color="#555" />
                </TouchableOpacity>
              </View>

              {/* Title Input */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Title</Text>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.input}
                    value={editTitle}
                    onChangeText={setEditTitle}
                    placeholder="Enter title"
                    placeholderTextColor="#aaa"
                  />
                </View>
              </View>

              {/* Amount Input */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Amount</Text>
                <View style={styles.inputContainer}>
                  <Text style={styles.inputPrefix}>₹</Text>
                  <TextInput
                    style={styles.input}
                    value={editAmount}
                    onChangeText={setEditAmount}
                    keyboardType="numeric"
                    placeholder="0.00"
                    placeholderTextColor="#aaa"
                  />
                </View>
              </View>

              {/* Category Selection */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Category</Text>
                {renderCategorySelector()}
              </View>

              {/* Date Input */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Date (YYYY-MM-DD)</Text>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.input}
                    value={editDate}
                    onChangeText={setEditDate}
                    placeholder="2024-01-15"
                    placeholderTextColor="#aaa"
                  />
                </View>
              </View>

              {/* Payment Method Selection */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Payment Method</Text>
                {renderPaymentSelector()}
              </View>

              {/* Action Buttons */}
              <View style={styles.editActionButtons}>
                <TouchableOpacity 
                  style={[styles.actionButton, styles.cancelButton]}
                  onPress={() => setIsEditing(false)}
                >
                  <Text style={styles.actionButtonText}>Cancel</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={[styles.actionButton, styles.saveButton]}
                  onPress={saveEdit}
                >
                  <Text style={styles.actionButtonText}>Save</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.2)",
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#fff",
    textAlign: "center",
    marginTop: 10,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  transactionItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  iconCircle: {
    width: 50,
    height: 50,
    borderRadius: 16,
    backgroundColor: "#f2f2f5",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 14,
  },
  transactionInfo: {
    flex: 1,
  },
  transactionName: {
    fontSize: 15,
    fontWeight: "600",
    color: "#111",
    marginBottom: 6,
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  categoryBadge: {
    backgroundColor: "#f2f2f5",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    marginRight: 10,
  },
  categoryText: {
    fontSize: 11,
    color: "#555",
    fontWeight: "500",
  },
  dateText: {
    fontSize: 11,
    color: "#888",
  },
  amountContainer: {
    alignItems: "flex-end",
  },
  amountText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#ff3b30",
  },
  paymentMethod: {
    fontSize: 10,
    color: "#888",
    marginTop: 4,
  },
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
  },
  emptyIcon: {
    fontSize: 60,
    marginBottom: 15,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#333",
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: "#777",
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 25,
    paddingBottom: 40,
    minHeight: "60%",
  },
  editScrollView: {
    maxHeight: "90%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  modalIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f2f2f5",
    justifyContent: "center",
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#111",
    textAlign: "center",
    marginBottom: 10,
  },
  modalAmount: {
    fontSize: 36,
    fontWeight: "700",
    color: "#ff3b30",
    textAlign: "center",
    marginBottom: 25,
  },
  detailSection: {
    backgroundColor: "#f8f8f8",
    borderRadius: 16,
    padding: 18,
    marginBottom: 25,
  },
  detailTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#555",
    marginBottom: 15,
  },
  detailRow: {
    flexDirection: "row",
    marginBottom: 15,
  },
  detailItem: {
    flex: 1,
  },
  detailItemFull: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 12,
    color: "#888",
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 15,
    fontWeight: "600",
    color: "#111",
  },
  // Action Buttons
  actionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  actionButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
    borderRadius: 12,
    marginHorizontal: 5,
  },
  editButton: {
    backgroundColor: "#3478f6",
  },
  deleteButton: {
    backgroundColor: "#ff3b30",
  },
  cancelButton: {
    backgroundColor: "#9ca3af",
  },
  saveButton: {
    backgroundColor: "#22c55e",
  },
  actionButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    marginLeft: 8,
  },
  doneButton: {
    backgroundColor: "#5f2eea",
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: "center",
  },
  doneButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#fff",
  },
  // Edit Modal Styles
  editModalTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#111",
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#555",
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f8f8f8",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  inputPrefix: {
    fontSize: 18,
    fontWeight: "600",
    color: "#111",
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 18,
    color: "#111",
    padding: 0,
  },
  editActionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  // Category Selector
  categorySelector: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  categoryOption: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: "#f2f2f5",
    marginRight: 8,
    marginBottom: 8,
  },
  categoryOptionSelected: {
    backgroundColor: "#5f2eea",
  },
  categoryIcon: {
    fontSize: 16,
    marginRight: 6,
  },
  categoryOptionText: {
    fontSize: 13,
    color: "#555",
    fontWeight: "500",
  },
  categoryOptionTextSelected: {
    color: "#fff",
  },
});
