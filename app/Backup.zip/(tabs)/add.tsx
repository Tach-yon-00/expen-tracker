import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Animated,
  Image,
  Modal,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import { useExpenses } from "../../context/ExpenseContext";
import { navVisibility } from "./_layout";

export default function AddScreen() {
  const router = useRouter();
  const { addExpense } = useExpenses();

  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Food & Dining");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState("Credit Card");
  const [notes, setNotes] = useState("");
  
  // Scan state
  const [isScanning, setIsScanning] = useState(false);
  const [showScanResult, setShowScanResult] = useState(false);
  const [scannedImage, setScannedImage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<{
    amount: string;
    description: string;
    category: string;
  } | null>(null);

  const categories: { name: string; icon: keyof typeof Ionicons.glyphMap }[] = [
    { name: "Food & Dining", icon: "restaurant-outline" },
    { name: "Transportation", icon: "car-outline" },
    { name: "Bills & Utilities", icon: "flash-outline" },
    { name: "Shopping", icon: "cart-outline" },
    { name: "Healthcare", icon: "medkit-outline" },
    { name: "Entertainment", icon: "film-outline" },
  ];

  const paymentMethods: { name: string; icon: keyof typeof Ionicons.glyphMap }[] = [
    { name: "UPI", icon: "phone-portrait-outline" },
    { name: "Credit Card", icon: "card-outline" },
    { name: "Debit Card", icon: "card-outline" },
    { name: "Cash", icon: "cash-outline" },
    { name: "Net Banking", icon: "globe-outline" },
  ];

  // Request camera permissions
  const requestPermissions = async () => {
    const { status: cameraStatus } = await ImagePicker.requestCameraPermissionsAsync();
    const { status: libraryStatus } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (cameraStatus !== 'granted' || libraryStatus !== 'granted') {
      Alert.alert(
        "Permissions Required",
        "Please grant camera and photo library permissions to scan receipts.",
        [{ text: "OK" }]
      );
      return false;
    }
    return true;
  };

  // Parse receipt text locally
  const parseReceiptText = (text: string): { amount: string; description: string; category: string } => {
    const textLower = text.toLowerCase();
    
    // Extract amount
    const amountPatterns = [
      /total[\s:]*[\₹$£€]?\s*(\d+[.,]\d{2})/i,
      /grand[\s]?total[\s:]*[\₹$£€]?\s*(\d+[.,]\d{2})/i,
      /amount[\s]?due[\s:]*[\₹$£€]?\s*(\d+[.,]\d{2})/i,
      /payable[\s:]*[\₹$£€]?\s*(\d+[.,]\d{2})/i,
      /sub[\s]?total[\s:]*[\₹$£€]?\s*(\d+[.,]\d{2})/i,
      /[\₹$£€]\s*(\d+\.\d{2})/,
    ];
    
    let extractedAmount = "";
    for (const pattern of amountPatterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        extractedAmount = match[1].replace(',', '.');
        break;
      }
    }
    
    if (!extractedAmount) {
      const priceMatch = text.match(/(\d+\.\d{2})/);
      if (priceMatch) {
        extractedAmount = priceMatch[1];
      }
    }
    
    // Extract description (store name)
    const lines = text.split('\n').filter(line => line.trim().length > 2);
    let extractedDescription = "";
    const skipWords = ['receipt', 'invoice', 'date', 'time', 'thank', 'welcome', 'gst', 'bill', 'copy', 'customer', 'http', 'www', 'tel', 'phone', 'address', 'mob', 'no', 'mobile', 'email'];
    
    for (const line of lines.slice(0, 5)) {
      const lowerLine = line.toLowerCase();
      if (!skipWords.some(word => lowerLine.includes(word))) {
        const letterCount = (line.match(/[a-zA-Z]/g) || []).length;
        if (letterCount >= 3) {
          extractedDescription = line.trim();
          break;
        }
      }
    }
    
    // Determine category
    let category = "Food & Dining";
    const categoryKeywords: Record<string, string[]> = {
      "Food & Dining": ['restaurant', 'cafe', 'coffee', 'pizza', 'burger', 'food', 'kitchen', 'diner', 'starbucks', 'mcdonald', 'domino', 'subway', 'zomato', 'swiggy', 'eat', 'dining', 'hotel', 'bakery', 'tea', 'juice', 'biryani', 'tiffin', 'kfc', 'pizza hut', 'dabba', 'lunch', 'dinner', 'breakfast', 'sandwich', 'soup', 'salad', ' dosa', 'idli', 'vada', 'puri', 'paratha', 'thali', 'bhelpuri', 'pakoda', 'samosa', 'chai', 'ice cream', 'dessert', 'sweet'],
      "Transportation": ['uber', 'lyft', 'taxi', 'fuel', 'gas', 'petrol', 'parking', 'metro', 'train', 'bus', 'airline', 'flight', 'ola', 'rapido', 'auto', 'cab', 'travel', 'railway', 'station', 'oil', 'fuel station', 'shell', 'bp', 'hpcl', 'indian oil', 'reliance petrol'],
      "Shopping": ['walmart', 'target', 'amazon', 'costco', 'store', 'shop', 'mall', 'market', 'retail', 'flipkart', 'myntra', 'meesho', 'bigbasket', 'blinkit', 'zepto', 'grocery', 'supermart', 'mart', 'dmart', 'reliance fresh', 'more', 'spencers', 'nature basket'],
      "Healthcare": ['pharmacy', 'medical', 'hospital', 'clinic', 'doctor', 'health', 'cvs', 'walgreens', 'medicine', 'drug', 'pathlab', 'diagnostic', 'healthcare', 'medplus', 'apollo', 'fortis', 'medicine', 'tablet', 'syrup', 'capsule', 'injection'],
      "Entertainment": ['movie', 'cinema', 'netflix', 'spotify', 'theatre', 'concert', 'game', 'hulu', 'disney', 'hotstar', 'prime', 'youtube', 'bookmyshow', 'pvr', 'imax', 'vodafone', 'jio', 'airtel', 'vodafone idea', 'recharge'],
      "Bills & Utilities": ['electric', 'water', 'bill', 'utility', 'power', 'airtel', 'jio', 'bsnl', 'recharge', 'prepaid', 'postpaid', 'broadband', 'wifi', 'internet', 'gas bill', 'electricity', 'mts', 'tata sky', 'dish tv']
    };
    
    for (const [cat, keywords] of Object.entries(categoryKeywords)) {
      if (keywords.some(keyword => textLower.includes(keyword))) {
        category = cat;
        break;
      }
    }
    
    return {
      amount: extractedAmount,
      description: extractedDescription,
      category
    };
  };

  // Process receipt with local OCR
  const processReceipt = async (base64: string, imageUri: string) => {
    setIsScanning(true);
    setScannedImage(imageUri);

    try {
      // Call OCR.space free API with base64
      const formData = new FormData();
      formData.append('base64Image', `data:image/jpeg;base64,${base64}`);
      formData.append('language', 'eng');
      formData.append('isOverlayRequired', 'false');
      formData.append('detectOrientation', 'true');
      formData.append('scale', 'true');
      formData.append('OCREngine', '2');
      
      const ocrResponse = await fetch('https://api.ocr.space/parse/image', {
        method: 'POST',
        headers: {
          'apikey': 'helloworld',
        },
        body: formData,
      });
      
      const ocrResult = await ocrResponse.json();
      
      if (ocrResult.IsErroredOnProcessing) {
        throw new Error(ocrResult.ErrorMessage?.[0] || 'OCR failed');
      }
      
      const extractedText = ocrResult.ParsedResults?.[0]?.ParsedText || '';
      
      if (!extractedText.trim()) {
        throw new Error('No text detected in image');
      }
      
      // Parse the extracted text locally
      const parsedData = parseReceiptText(extractedText);
      setExtractedData(parsedData);
      
      // Auto-fill the form
      if (parsedData.amount) {
        setAmount(parsedData.amount);
      }
      if (parsedData.description) {
        setDescription(parsedData.description);
      }
      setSelectedCategory(parsedData.category);
      
      setShowScanResult(true);
      
    } catch (error) {
      console.error("Scan Error:", error);
      setShowScanResult(true);
      Alert.alert(
        "Notice", 
        "Could not extract details automatically. Please enter manually and cross-check."
      );
    } finally {
      setIsScanning(false);
    }
  };

  // Take photo with camera
  const takePhoto = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.8,
      base64: true,
    });

    if (!result.canceled && result.assets[0]) {
      const imageUri = result.assets[0].uri;
      setScannedImage(imageUri);
      if (result.assets[0].base64) {
        await processReceipt(result.assets[0].base64, imageUri);
      }
    }
  };

  // Pick from gallery
  const pickFromGallery = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.8,
      base64: true,
    });

     if (!result.canceled && result.assets[0]) {
      const imageUri = result.assets[0].uri;
      setScannedImage(imageUri);
      if (result.assets[0].base64) {
        await processReceipt(result.assets[0].base64, imageUri);
      }
    }
  };

  // Show image picker options
  const showScanOptions = () => {
    Alert.alert(
      "Scan Receipt",
      "Choose how to scan your receipt",
      [
        { text: "Take Photo", onPress: takePhoto },
        { text: "Choose from Gallery", onPress: pickFromGallery },
        { text: "Cancel", style: "cancel" },
      ]
    );
  };

  // Save the expense
  const handleAddExpense = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      Alert.alert("Error", "Please enter a valid amount");
      return;
    }

    if (!description.trim()) {
      Alert.alert("Error", "Please enter a description");
      return;
    }

    // Show warning before saving
    Alert.alert(
      "⚠️ Please Cross-Check",
      `Before saving, please verify:\n\n• Amount: ₹${amount}\n• Description: ${description}\n• Category: ${selectedCategory}\n\nAI may make mistakes. Please confirm the details are correct.`,
      [
        { text: "Go Back & Edit", style: "cancel" },
        { 
          text: "Save Anyway", 
          onPress: async () => {
            try {
              await addExpense({
                id: Date.now().toString(),
                title: description,
                amount: parseFloat(amount),
                category: selectedCategory,
                date: selectedDate,
                payment: paymentMethod,
                notes: notes,
              });
              router.back();
            } catch (error) {
              Alert.alert("Error", "Failed to add expense");
            }
          }
        }
      ]
    );
  };

  // Apply AI suggestion
  const applySuggestion = () => {
    Alert.alert(
      "🚧 Under Development",
      "It is still under Development.\n\n☕ Buy me a coffee and support our project!",
      [{ text: "OK" }]
    );
  };

  // Clear scanned image
  const clearScannedImage = () => {
    setScannedImage(null);
    setShowScanResult(false);
    setExtractedData(null);
  };

  return (
    <View style={styles.container}>
      <Animated.ScrollView 
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: navVisibility } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >

        {/* HEADER */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color="#111" />
          </TouchableOpacity>

          <Text style={styles.title}>Add Expense</Text>
          <View style={{ width: 22 }} />
        </View>

        {/* SCAN CARD */}
        <TouchableOpacity style={styles.scanCard} onPress={showScanOptions}>
          <View style={styles.iconBox}>
            <Ionicons name="scan-outline" size={28} color="#6a5cff" />
          </View>

          <Text style={styles.scanTitle}>Scan Receipt</Text>

          <Text style={styles.scanSubtitle}>
            Auto-extracts details - please cross-check
          </Text>

          <View style={styles.scanButton}>
            <Ionicons name="scan-outline" size={18} color="#6a5cff" />
            <Text style={styles.scanButtonText}>  Scan & Auto-Fill</Text>
          </View>
        </TouchableOpacity>

        {/* AMOUNT CARD */}
        <View style={styles.amountCard}>
          <Text style={styles.amountLabel}>Amount *</Text>

          <View style={styles.amountInput}>
            <Text style={styles.currency}>₹</Text>
            <TextInput
              style={styles.amountValue}
              keyboardType="numeric"
              value={amount}
              onChangeText={setAmount}
              placeholder="0.00"
              placeholderTextColor="#ccc"
            />
          </View>
        </View>

        {/* DESCRIPTION CARD */}
        <View style={styles.descriptionCard}>
          <Text style={styles.descriptionLabel}>Description *</Text>

          <TextInput
            style={styles.descriptionInput}
            value={description}
            onChangeText={setDescription}
            placeholder="Enter description"
            placeholderTextColor="#999"
          />

          {/* AI SUGGESTION */}
          <TouchableOpacity style={styles.aiCard} onPress={applySuggestion}>
            <View style={styles.aiHeader}>
              <Ionicons name="sparkles-outline" size={18} color="#3478f6" />
              <Text style={styles.aiTitle}>  AI Suggestion</Text>
            </View>

            <Text style={styles.aiText}>
              Click to get AI-generated expense details
            </Text>

            <View style={styles.applyButton}>
              <Text style={styles.applyButtonText}>⚡ Apply Suggestion</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* CATEGORY CARD */}
        <View style={styles.card}>
          <Text style={styles.sectionLabel}>Category *</Text>

          <View style={styles.categoryGrid}>
            {categories.map((cat, index) => {
              const isActive = selectedCategory === cat.name;

              return (
                <TouchableOpacity
                  key={index}
                  style={[
                    styles.categoryItem,
                    isActive && styles.activeCategory,
                  ]}
                  onPress={() => setSelectedCategory(cat.name)}
                >
                  <Ionicons
                    name={cat.icon}
                    size={20}
                    color={isActive ? "#6a5cff" : "#555"}
                  />
                  <Text
                    style={[
                      styles.categoryText,
                      isActive && { color: "#6a5cff" },
                    ]}
                  >
                    {cat.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* DATE CARD */}
        <View style={styles.smallCard}>
          <Text style={styles.sectionLabel}>Date</Text>
          <View style={styles.smallInput}>
            <Ionicons name="calendar-outline" size={16} color="#555" />
            <TextInput
              style={styles.smallTextInput}
              value={selectedDate}
              onChangeText={setSelectedDate}
              placeholder="YYYY-MM-DD"
              placeholderTextColor="#999"
            />
          </View>
        </View>

        {/* PAYMENT CARD */}
        <View style={styles.smallCard}>
          <Text style={styles.sectionLabel}>Payment</Text>
          <View style={styles.paymentGrid}>
            {paymentMethods.map((method, index) => {
              const isActive = paymentMethod === method.name;
              return (
                <TouchableOpacity
                  key={index}
                  style={[
                    styles.paymentOption,
                    isActive && styles.paymentOptionActive,
                  ]}
                  onPress={() => setPaymentMethod(method.name)}
                >
                  <Ionicons
                    name={method.icon}
                    size={18}
                    color={isActive ? "#6a5cff" : "#555"}
                  />
                  <Text style={[
                    styles.paymentText,
                    isActive && styles.paymentTextActive,
                  ]}>
                    {method.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* NOTES CARD */}
        <View style={styles.notesCard}>
          <Text style={styles.sectionLabel}>Notes (Optional)</Text>

          <TextInput
            style={styles.notesInput}
            placeholder="Weekly grocery shopping..."
            placeholderTextColor="#999"
            multiline
            value={notes}
            onChangeText={setNotes}
          />
        </View>

        {/* ADD BUTTON */}
        <TouchableOpacity style={styles.addButton} onPress={handleAddExpense}>
          <Text style={styles.addButtonText}>Add Expense</Text>
        </TouchableOpacity>

      </Animated.ScrollView>

      {/* Loading Modal */}
      <Modal
        visible={isScanning}
        transparent
        animationType="fade"
      >
        <View style={styles.loadingOverlay}>
          <View style={styles.loadingContent}>
            <ActivityIndicator size="large" color="#6a5cff" />
            <Text style={styles.loadingText}>Scanning Receipt...</Text>
            <Text style={styles.loadingSubtext}>AI is extracting details</Text>
          </View>
        </View>
      </Modal>

      {/* Scan Result Modal */}
      <Modal
        visible={showScanResult && !isScanning}
        transparent
        animationType="slide"
      >
        <View style={styles.resultOverlay}>
          <View style={styles.resultContent}>
            <View style={styles.resultHeader}>
              <Ionicons name="checkmark-circle" size={50} color="#22c55e" />
              <Text style={styles.resultTitle}>Receipt Scanned!</Text>
            </View>

            {scannedImage && (
              <Image
                source={{ uri: scannedImage }}
                style={styles.scannedImage}
                resizeMode="cover"
              />
            )}

            {/* WARNING MESSAGE */}
            <View style={styles.warningBox}>
              <Ionicons name="warning-outline" size={22} color="#f59e0b" />
              <Text style={styles.warningText}>
                ⚠️ AI may make mistakes! Please cross-check all extracted details before saving.
              </Text>
            </View>

            {extractedData && (
              <View style={styles.resultDetails}>
                <Text style={styles.resultLabel}>AI Extracted Details:</Text>
                {extractedData.amount ? (
                  <Text style={styles.resultText}>✓ Amount: ₹{extractedData.amount}</Text>
                ) : (
                  <Text style={[styles.resultText, { color: '#ff6b6b' }]}>✗ Amount: Not detected</Text>
                )}
                {extractedData.description ? (
                  <Text style={styles.resultText}>✓ Store: {extractedData.description}</Text>
                ) : (
                  <Text style={[styles.resultText, { color: '#ff6b6b' }]}>✗ Store: Not detected</Text>
                )}
                <Text style={styles.resultText}>✓ Category: {extractedData.category}</Text>
              </View>
            )}

            <TouchableOpacity
              style={styles.confirmButton}
              onPress={clearScannedImage}
            >
              <Text style={styles.confirmButtonText}>Looks Good! ✓</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#ffffff",
    paddingTop: 60,
    paddingHorizontal: 24,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 30,
  },

  title: {
    fontSize: 18,
    fontWeight: "600",
  },

  /* ---------- SCAN CARD ---------- */

  scanCard: {
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderColor: "#6a5cff",
    borderRadius: 20,
    padding: 30,
    alignItems: "center",
    backgroundColor: "#f7f8ff",
    marginBottom: 25,
  },

  iconBox: {
    width: 70,
    height: 70,
    borderRadius: 20,
    backgroundColor: "#e9e8ff",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },

  scanTitle: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 8,
  },

  scanSubtitle: {
    fontSize: 13,
    color: "#777",
    textAlign: "center",
    marginBottom: 25,
  },

  scanButton: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: "#6a5cff",
    borderRadius: 15,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },

  scanButtonText: {
    color: "#6a5cff",
    fontWeight: "500",
  },

  /* ---------- AMOUNT CARD ---------- */

  amountCard: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 4,
    marginBottom: 25,
  },

  amountLabel: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: 12,
    color: "#111",
  },

  amountInput: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: "#6a5cff",
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
  },

  currency: {
    fontSize: 20,
    color: "#999",
    marginRight: 10,
  },

  amountValue: {
    fontSize: 26,
    fontWeight: "700",
    color: "#111",
    flex: 1,
  },

  /* ---------- DESCRIPTION CARD ---------- */

  descriptionCard: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 4,
    marginBottom: 40,
  },

  descriptionLabel: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: 10,
  },

  descriptionInput: {
    backgroundColor: "#f4f5f7",
    borderRadius: 14,
    padding: 14,
    marginBottom: 20,
    fontSize: 16,
  },

  aiCard: {
    backgroundColor: "#eaf1ff",
    borderRadius: 16,
    padding: 16,
  },

  aiHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },

  aiTitle: {
    color: "#3478f6",
    fontWeight: "600",
  },

  aiText: {
    color: "#3a4a7a",
    marginBottom: 15,
  },

  applyButton: {
    backgroundColor: "#3478f6",
    borderRadius: 12,
    paddingVertical: 10,
    alignItems: "center",
  },

  applyButtonText: {
    color: "#ffffff",
    fontWeight: "600",
  },

  /* ---------- CATEGORY CARD ---------- */

  card: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 4,
    marginBottom: 25,
  },

  sectionLabel: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: 15,
  },

  categoryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  categoryItem: {
    width: "48%",
    backgroundColor: "#f5f6f8",
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 14,
  },

  activeCategory: {
    backgroundColor: "#eef0ff",
    borderWidth: 1.5,
    borderColor: "#6a5cff",
  },

  categoryText: {
    marginLeft: 8,
    fontSize: 13,
    color: "#333",
  },

  /* ---------- DATE & PAYMENT ---------- */

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  smallCard: {
    width: "100%",
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 4,
    marginBottom: 25,
  },

  smallInput: {
    backgroundColor: "#f5f6f8",
    borderRadius: 12,
    padding: 10,
    flexDirection: "row",
    alignItems: "center",
  },

  smallTextInput: {
    fontSize: 13,
    color: "#333",
    flex: 1,
    marginLeft: 5,
  },

  paymentGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  paymentOptions: {
    flexDirection: "row",
    gap: 8,
  },

  paymentOption: {
    width: "48%",
    backgroundColor: "#f5f6f8",
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 14,
  },

  paymentOptionActive: {
    backgroundColor: "#eef0ff",
    borderWidth: 1.5,
    borderColor: "#6a5cff",
  },

  paymentText: {
    fontSize: 13,
    color: "#333",
    marginLeft: 8,
  },

  paymentTextActive: {
    color: "#6a5cff",
    fontWeight: "600",
  },

  /* ---------- NOTES CARD ---------- */

  notesCard: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 4,
    marginBottom: 25,
  },

  notesInput: {
    backgroundColor: "#f5f6f8",
    borderRadius: 14,
    padding: 14,
    minHeight: 90,
    textAlignVertical: "top",
    fontSize: 16,
  },

  addButton: {
    backgroundColor: "#6a5cff",
    borderRadius: 18,
    paddingVertical: 16,
    alignItems: "center",
    marginBottom: 120,
  },

  addButtonText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "600",
  },

  /* ---------- LOADING MODAL ---------- */

  loadingOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "center",
    alignItems: "center",
  },

  loadingContent: {
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 40,
    alignItems: "center",
  },

  loadingText: {
    fontSize: 18,
    fontWeight: "600",
    marginTop: 20,
    color: "#333",
  },

  loadingSubtext: {
    fontSize: 14,
    color: "#777",
    marginTop: 8,
  },

  /* ---------- SCAN RESULT MODAL ---------- */

  resultOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "flex-end",
  },

  resultContent: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 30,
    maxHeight: "85%",
  },

  resultHeader: {
    alignItems: "center",
    marginBottom: 20,
  },

  resultTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#22c55e",
    marginTop: 10,
  },

  scannedImage: {
    width: "100%",
    height: 180,
    borderRadius: 15,
    marginBottom: 15,
  },

  warningBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fef3c7",
    borderRadius: 12,
    padding: 14,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#f59e0b",
  },

  warningText: {
    flex: 1,
    fontSize: 13,
    color: "#92400e",
    marginLeft: 10,
    fontWeight: "500",
  },

  resultDetails: {
    backgroundColor: "#f5f6f8",
    borderRadius: 15,
    padding: 15,
    marginBottom: 20,
  },

  resultLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
    marginBottom: 10,
  },

  resultText: {
    fontSize: 14,
    color: "#555",
    marginBottom: 5,
  },

  confirmButton: {
    backgroundColor: "#6a5cff",
    borderRadius: 15,
    paddingVertical: 16,
    alignItems: "center",
  },

  confirmButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },

});
