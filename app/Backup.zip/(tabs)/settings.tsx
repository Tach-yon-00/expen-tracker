import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import {
  Animated,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { navVisibility } from "./_layout";

export default function SettingsScreen() {

  const [dark, setDark] = useState(false);
  const [push, setPush] = useState(true);
  const [budget, setBudget] = useState(true);

  return (
    <View style={styles.container}>
      <Animated.ScrollView 
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: navVisibility } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >

        <Text style={styles.title}>Settings</Text>

        {/* ================= PROFILE ================= */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>
            <Ionicons name="person-outline" size={16} /> Profile
          </Text>

          <View style={styles.profileRow}>
            <View style={styles.avatar}>
              <Text style={{ color: "#fff", fontWeight: "700" }}>SA</Text>
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Full Name</Text>
              <View style={styles.input}><Text>User</Text></View>

              <Text style={styles.label}>Monthly Budget</Text>
              <View style={styles.input}><Text>₹300</Text></View>
            </View>
          </View>
        </View>

        {/* ================= EXPORT ================= */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>
            <Ionicons name="download-outline" size={16} /> Export Data
          </Text>

          <View style={styles.row}>
            <View style={styles.exportBtn}>
              <Ionicons name="document-text-outline" size={26} />
              <Text>Export CSV</Text>
            </View>

            <View style={styles.exportBtn}>
              <Ionicons name="document-text-outline" size={26} />
              <Text>Export PDF</Text>
            </View>
          </View>

          <Text style={styles.smallText}>
            Export your expense data for backup or analysis in other tools.
          </Text>
        </View>

        {/* ================= SYNC ================= */}
        {/* ================= SYNC & BACKUP ================= */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>
            <Ionicons name="folder-open-outline" size={16} /> Sync & Backup
          </Text>

          <View style={styles.syncContainer}>

            <View style={styles.syncTopRow}>
              <View style={styles.driveIcon}>
                <Ionicons name="logo-google" size={18} color="#2563eb" />
              </View>

              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={styles.driveTitle}>Google Drive Backup</Text>
                <Text style={styles.driveSub}>Last backup: 2 hours ago</Text>
              </View>

              <View style={styles.connectedBadge}>
                <Text style={styles.connectedText}>Connected</Text>
              </View>
            </View>

            <View style={styles.syncButtonsRow}>
              <TouchableOpacity style={styles.syncBtn}>
                <Text style={styles.syncBtnText}>Backup Now</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.syncBtn}>
                <Text style={styles.syncBtnText}>Sync Data</Text>
              </TouchableOpacity>
            </View>

          </View>
        </View>


        {/* ================= CUSTOM CATEGORY ================= */}
        {/* ================= CUSTOM CATEGORIES ================= */}
        <View style={styles.card}>
          <View style={styles.categoryHeader}>
            <Text style={styles.sectionTitle}>
              <Ionicons name="pricetag-outline" size={16} /> Custom Categories
            </Text>

            <TouchableOpacity style={styles.addBtn}>
              <Ionicons name="add" size={18} color="#fff" />
            </TouchableOpacity>
          </View>

          {[
            { name: "Coffee & Drinks", count: "15 transactions", color: "#f97316", icon: "cafe" },
            { name: "Gym & Fitness", count: "8 transactions", color: "#22c55e", icon: "barbell" },
            { name: "Pet Expenses", count: "12 transactions", color: "#3b82f6", icon: "paw" },
          ].map((item, i) => (
            <View key={i} style={styles.categoryCard}>

              {/* LEFT SIDE */}
              <View style={{ flexDirection: "row", alignItems: "center", flex: 1 }}>
                <View style={[styles.categoryIcon, { backgroundColor: item.color }]}>
                  <Ionicons name={item.icon as any} size={16} color="#fff" />
                </View>

                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.categoryTitle}>{item.name}</Text>
                  <Text style={styles.categorySub}>{item.count}</Text>
                </View>
              </View>

              {/* RIGHT ACTIONS */}
              <View style={styles.actions}>
                <TouchableOpacity style={styles.iconBtn}>
                  <Ionicons name="pencil" size={15} color="#6b7280" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.iconBtn}>
                  <Ionicons name="trash" size={15} color="#ef4444" />
                </TouchableOpacity>
              </View>

            </View>
          ))}
        </View>



        {/* ================= PREFERENCES ================= */}
        <View style={styles.cardSpacing}>
          <View style={styles.card}>

            <Text style={styles.sectionTitle}>
              <Ionicons name="settings-outline" size={16} /> Preferences
            </Text>

            <View style={styles.prefRow}>
              <View style={styles.prefLeft}>
                <View style={styles.prefIconBox}>
                  <Ionicons name="moon-outline" size={16} color="#6b7280" />
                </View>

                <View>
                  <Text style={styles.prefTitle}>Dark Mode</Text>
                  <Text style={styles.prefSub}>Switch to dark theme</Text>
                </View>
              </View>

              <Switch value={dark} onValueChange={setDark} />
            </View>

            <View style={styles.prefRow}>
              <View style={styles.prefLeft}>
                <View style={styles.prefIconBox}>
                  <Ionicons name="notifications-outline" size={16} color="#6b7280" />
                </View>

                <View>
                  <Text style={styles.prefTitle}>Push Notifications</Text>
                  <Text style={styles.prefSub}>Get notified about expenses</Text>
                </View>
              </View>

              <Switch value={push} onValueChange={setPush} />
            </View>

            <View style={styles.prefRow}>
              <View style={styles.prefLeft}>
                <View style={styles.prefIconBox}>
                  <Ionicons name="shield-outline" size={16} color="#6b7280" />
                </View>

                <View>
                  <Text style={styles.prefTitle}>Budget Alerts</Text>
                  <Text style={styles.prefSub}>Alert when overspending</Text>
                </View>
              </View>

              <Switch value={budget} onValueChange={setBudget} />
            </View>

          </View>
        </View>


        {/* ================= SECURITY ================= */}
        <View style={styles.cardSpacing}>
          <View style={styles.card}>

            <Text style={styles.sectionTitle}>
              <Ionicons name="shield-outline" size={16} /> Security & Privacy
            </Text>

            {[
              { icon: "card-outline", label: "Manage Payment Methods" },
              { icon: "lock-closed-outline", label: "Change Password" },
              { icon: "person-outline", label: "Privacy Settings" },
            ].map((item, i) => (
              <TouchableOpacity key={i} style={styles.securityRow}>
                <Ionicons name={item.icon as any} size={16} color="#4b5563" />
                <Text style={styles.securityText}>{item.label}</Text>
              </TouchableOpacity>
            ))}

          </View>
        </View>


        {/* ================= FOOTER ================= */}
        <View style={styles.footer}>
          <Text style={styles.smallText}>ExpenseTracker v2.1.0</Text>
          <Text style={{ marginTop: 8 }}>Terms   Privacy   Help</Text>
        </View>

      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 50,
    paddingHorizontal: 14,
  },

  title: {
    fontSize: 30,
    fontWeight: "700",
    marginBottom: 15,
  },

  card: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 16,
    padding: 14,
    marginBottom: 14,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 14,
  },

  profileRow: {
    flexDirection: "row",
  },

  avatar: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: "#4f46e5",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },

  label: {
    fontSize: 12,
    color: "#666",
    marginTop: 6,
    marginBottom: 4,
  },

  input: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    padding: 10,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 12,
  },

  exportBtn: {
    width: "48%",
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 12,
    padding: 14,
    alignItems: "center",
  },

  smallText: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 8,
  },

  syncBox: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 12,
    padding: 12,
  },

  syncTitle: {
    fontWeight: "700",
    fontSize: 16,
  },

  connected: {
    marginTop: 6,
    alignSelf: "flex-start",
    backgroundColor: "#dcfce7",
    color: "#16a34a",
    paddingHorizontal: 8,
    borderRadius: 8,
    fontSize: 12,
  },

  actionBtn: {
    width: "48%",
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
  },

  categoryItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
  },

  toggleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
  },

  securityBtn: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    padding: 14,
    marginBottom: 8,
  },

  footer: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    marginBottom: 120,
  },

  syncContainer: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 14,
    padding: 12,
  },

  syncTopRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  driveIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: "#eff6ff",
    justifyContent: "center",
    alignItems: "center",
  },

  driveTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },

  driveSub: {
    fontSize: 13,
    color: "#6b7280",
    marginTop: 2,
  },

  connectedBadge: {
    backgroundColor: "#dcfce7",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },

  connectedText: {
    color: "#16a34a",
    fontSize: 12,
    fontWeight: "600",
  },

  syncButtonsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  syncBtn: {
    width: "48%",
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "#fff",
  },

  syncBtnText: {
    fontSize: 15,
    fontWeight: "500",
  },

  categoryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },

  addBtn: {
    width: 30,
    height: 30,
    borderRadius: 8,
    backgroundColor: "#4f46e5",
    justifyContent: "center",
    alignItems: "center",
  },

  categoryCard: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
  },

  categoryIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },

  categoryTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#111827",
  },

  categorySub: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 2,
  },

  actions: {
    flexDirection: "row",
    gap: 8,
  },

  iconBtn: {
    width: 30,
    height: 30,
    borderRadius: 8,
    backgroundColor: "#f3f4f6",
    justifyContent: "center",
    alignItems: "center",
  },

  /* ===== GLOBAL CARD SPACING ===== */

cardSpacing: {
  marginBottom: 14,
},

/* ===== PREFERENCES ===== */

prefRow: {
  flexDirection: "row",
  alignItems: "center",
  justifyContent: "space-between",
  marginBottom: 14,
},

prefLeft: {
  flexDirection: "row",
  alignItems: "center",
},

prefIconBox: {
  width: 34,
  height: 34,
  borderRadius: 10,
  backgroundColor: "#f3f4f6",
  justifyContent: "center",
  alignItems: "center",
  marginRight: 10,
},

prefTitle: {
  fontSize: 17,
  fontWeight: "600",
  color: "#111827",
},

prefSub: {
  fontSize: 13,
  color: "#6b7280",
  marginTop: 2,
},

/* ===== SECURITY ===== */

securityRow: {
  flexDirection: "row",
  alignItems: "center",
  borderWidth: 1,
  borderColor: "#e5e7eb",
  borderRadius: 12,
  paddingVertical: 14,
  paddingHorizontal: 12,
  marginBottom: 10,
},

securityText: {
  fontSize: 16,
  marginLeft: 10,
  fontWeight: "500",
  color: "#111827",
},



});
