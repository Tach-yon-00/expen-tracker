import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { PieChart } from "react-native-svg-charts";
import { useExpenses } from "../../context/ExpenseContext";
import { navVisibility } from "./_layout";

export default function HomeScreen() {

  const router = useRouter();
  const progress = useRef(new Animated.Value(0)).current;
  const { state, budget } = useExpenses();

  // Use budget from context, fallback to 3500 if not loaded yet
  const MONTHLY_BUDGET = budget || 3500;

  // total spent
  const totalSpent = state.expenses.reduce(
    (sum: number, item: any) => sum + item.amount,
    0
  );

  // 🚀 STEP 1 — Date Helpers
  const now = new Date();

  // Get current month name and year for display
  const currentMonthName = now.toLocaleString('default', { month: 'long' });
  const currentYear = now.getFullYear();

  // days left in current month
  const lastDay = new Date(
    now.getFullYear(),
    now.getMonth() + 1,
    0
  ).getDate();

  const currentDate = now.getDate();
  const daysLeft = lastDay - currentDate;
  
  // Calculate end of month date for display
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const endDateStr = endOfMonth.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  // 🚀 STEP 2 — Calculate THIS MONTH vs LAST MONTH
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();

  const currentMonthExpenses = state.expenses.filter((e: any) => {
    const d = new Date(e.date);
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  });

  const lastMonthExpenses = state.expenses.filter((e: any) => {
    const d = new Date(e.date);
    return (
      d.getMonth() === thisMonth - 1 &&
      d.getFullYear() === thisYear
    );
  });

  const currentTotal = currentMonthExpenses.reduce(
    (s: number, e: any) => s + e.amount,
    0
  );

  const lastTotal = lastMonthExpenses.reduce(
    (s: number, e: any) => s + e.amount,
    0
  );

  // Calculate savings percentage vs last month
  const savingsPercent = lastTotal > 0
    ? (((lastTotal - currentTotal) / lastTotal) * 100).toFixed(1)
    : 0;
  
  const isSaved = Number(savingsPercent) > 0;
  const savingsColor = isSaved ? "#2ecc71" : "#ff3b30";

  const remaining = MONTHLY_BUDGET - totalSpent;

  const usedPercent = Math.min(
    (totalSpent / MONTHLY_BUDGET) * 100,
    100
  );

  useEffect(() => {
    Animated.timing(progress, {
      toValue: usedPercent,
      duration: 1200,
      useNativeDriver: false,
    }).start();
  }, [usedPercent]);

  const widthInterpolated = progress.interpolate({
    inputRange: [0, 100],
    outputRange: ["0%", "100%"],
  });

  // 🚀 STEP 3 — Calculate Category Data
  const categoryTotals: any = {};

  state.expenses.forEach((e: any) => {
    if (!categoryTotals[e.category]) {
      categoryTotals[e.category] = 0;
    }
    categoryTotals[e.category] += e.amount;
  });

  const COLORS: any = {
    Food: "#ff3b30",
    Transport: "#3b82f6",
    Bills: "#22c55e",
    Shopping: "#f59e0b",
    Others: "#9ca3af",
  };

  const totalCategorySpent: number = Object.values(categoryTotals)
    .reduce((a: any, b: any) => a + b, 0);

  const pieData = Object.keys(categoryTotals).map((key, index) => ({
    key: `${key}-${index}`,
    value: categoryTotals[key],
    svg: { fill: COLORS[key] || "#9ca3af" },
  }));

  // Helper to format date
  const formatDate = (dateStr: string | undefined) => {
    if (!dateStr) return "Today";
    const date = new Date(dateStr);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Get category icon
  const getCategoryIcon = (category: string) => {
    const icons: any = { Food: "🍔", Transport: "🚗", Bills: "💡", Shopping: "🛒", Others: "📦" };
    return icons[category] || "📦";
  };

  return (
    <Animated.ScrollView 
      style={styles.container} 
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
      onScroll={Animated.event(
        [{ nativeEvent: { contentOffset: { y: navVisibility } } }],
        { useNativeDriver: false }
      )}
      scrollEventThrottle={16}
    >

      {/* HEADER */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Hello, User! 👋</Text>
          <Text style={styles.subGreeting}>Track your expenses wisely</Text>
        </View>

        <TouchableOpacity
          style={styles.addButton}
          onPress={() => router.push("/add")}
        >
          <Ionicons name="add" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* BUDGET CARD */}
      <LinearGradient
        colors={["#5f2eea", "#7b3fe4", "#8e44ff"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Total Spent This Month</Text>
          <View style={styles.moneyIcon}>
            <Text style={styles.moneyText}>₹</Text>
          </View>
        </View>

        <Text style={styles.amount}>₹{totalSpent}</Text>

        <View style={styles.row}>
          <Text style={styles.smallText}>Budget: ₹{MONTHLY_BUDGET}</Text>
          <Text style={styles.smallText}>Remaining: ₹{remaining}</Text>
        </View>

        <View style={styles.progressBar}>
          <Animated.View style={[styles.progressFill, { width: widthInterpolated }]} />
        </View>

        <View style={styles.row}>
          <Text style={styles.smallText}>{usedPercent.toFixed(1)}% used</Text>
          <Text style={styles.smallText}>{endDateStr} ({daysLeft} days left)</Text>
        </View>

      </LinearGradient>

      {/* SUMMARY SMALL CARDS */}
      <View style={styles.summaryRow}>

        {/* Savings vs Last Month Card */}
        <View style={styles.summaryCard}>
          <View style={[styles.summaryIcon, { backgroundColor: isSaved ? "#e6f7ec" : "#ffeaea" }]}>
            <Text style={{ fontSize: 16 }}>{isSaved ? "💰" : "📈"}</Text>
          </View>
          <Text style={styles.summaryLabel}>Saved vs Last Month</Text>
          <Text style={[styles.summaryValue, { color: savingsColor }]}>
            {isSaved ? "" : "+"}{savingsPercent}%
          </Text>
        </View>

        {/* Days Left Card */}
        <View style={styles.summaryCard}>
          <View style={[styles.summaryIcon, { backgroundColor: "#e8f0ff" }]}>
            <Text style={{ fontSize: 16 }}>📅</Text>
          </View>
          <Text style={styles.summaryLabel}>Days Left</Text>
          <Text style={[styles.summaryValue, { color: "#3478f6" }]}>
            {daysLeft} days
          </Text>
        </View>

      </View>

      {/* CATEGORY CARD */}
      <View style={styles.categoryCard}>

        <View style={styles.categoryHeader}>
          <Text style={styles.categoryTitle}>Spending by Category</Text>
          <View style={styles.monthBadge}>
            <Text style={styles.monthText}>{currentMonthName} {currentYear}</Text>
          </View>
        </View>

        <View style={styles.categoryContent}>

          {/* PIE CHART */}
          <PieChart
            style={{ height: 140, width: 140 }}
            data={pieData}
            innerRadius={"60%"}
          />

          {/* CATEGORY LIST */}
          <View style={styles.legend}>
            {Object.keys(categoryTotals).map((cat, i) => {
              const amount = categoryTotals[cat];
              const percent = totalCategorySpent > 0 ? ((amount / totalCategorySpent) * 100).toFixed(0) : 0;

              return (
                <View key={i} style={styles.legendRow}>
                  <View style={[styles.dot, { backgroundColor: COLORS[cat] || "#999" }]} />
                  <Text style={styles.legendName}>{cat}</Text>
                  <View style={styles.legendRight}>
                    <Text style={styles.legendAmount}>₹{amount}</Text>
                    <Text style={styles.legendPercent}>{percent}%</Text>
                  </View>
                </View>
              );
            })}
          </View>

        </View>

      </View>

      {/* RECENT TRANSACTIONS CARD */}
      <View style={styles.transactionCard}>

        <View style={styles.transactionHeader}>
          <Text style={styles.transactionTitle}>Recent Transactions</Text>
          <TouchableOpacity onPress={() => router.push("/transactions")}>
            <Text style={styles.viewAll}>View All</Text>
          </TouchableOpacity>
        </View>

        {/* Get recent 4 transactions from state */}
        {state.expenses.slice(0, 4).map((item: any, index: number) => (
          <TouchableOpacity 
            key={index} 
            style={styles.transactionRow}
            onPress={() => router.push("/transactions")}
            activeOpacity={0.7}
          >
            <View style={styles.iconCircle}>
              <Text>{getCategoryIcon(item.category)}</Text>
            </View>

            <View style={styles.transactionInfo}>
              <Text style={styles.transactionName}>
                {item.description || `${item.category} Expense`}
              </Text>

              <View style={styles.metaRow}>
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{item.category}</Text>
                </View>
                <Text style={styles.dateText}>{formatDate(item.date)}</Text>
              </View>
            </View>

            <Text style={styles.amountText}>-₹{item.amount}</Text>
          </TouchableOpacity>
        ))}

        {state.expenses.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>No transactions yet</Text>
          </View>
        )}

      </View>

    </Animated.ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#ffffff",
  },

  scrollContent: {
    paddingTop: 60,
    paddingHorizontal: 24,
    paddingBottom: 40,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 25,
  },

  greeting: {
    fontSize: 20,
    fontWeight: "600",
    color: "#111",
  },

  subGreeting: {
    fontSize: 13,
    color: "#777",
    marginTop: 4,
  },

  addButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "#6C5CE7",
    alignItems: "center",
    justifyContent: "center",
  },

  card: {
    borderRadius: 25,
    padding: 22,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 15,
    elevation: 10,
  },

  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  cardTitle: {
    color: "#e0d9ff",
    fontSize: 13,
  },

  moneyIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.2)",
    justifyContent: "center",
    alignItems: "center",
  },

  moneyText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
  },

  amount: {
    color: "#fff",
    fontSize: 30,
    fontWeight: "700",
    marginVertical: 12,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 8,
  },

  smallText: {
    color: "#e0d9ff",
    fontSize: 12,
  },

  progressBar: {
    height: 6,
    backgroundColor: "rgba(255,255,255,0.3)",
    borderRadius: 6,
    overflow: "hidden",
    marginTop: 10,
  },

  progressFill: {
    height: "100%",
    backgroundColor: "#ffffff",
  },

  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },

  summaryCard: {
    width: "48%",
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 18,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },

  summaryIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },

  summaryLabel: {
    fontSize: 12,
    color: "#777",
    marginBottom: 6,
  },

  summaryValue: {
    fontSize: 16,
    fontWeight: "600",
  },

  categoryCard: {
    backgroundColor: "#ffffff",
    marginTop: 25,
    padding: 20,
    borderRadius: 25,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 6,
  },

  categoryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 15,
  },

  categoryTitle: {
    fontSize: 16,
    fontWeight: "600",
  },

  monthBadge: {
    backgroundColor: "#f2f2f5",
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
  },

  monthText: {
    fontSize: 12,
    color: "#555",
  },

  categoryContent: {
    flexDirection: "row",
  },

  legend: {
    flex: 1,
    marginLeft: 15,
  },

  legendRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },

  legendName: {
    flex: 1,
    fontSize: 13,
  },

  legendRight: {
    alignItems: "flex-end",
  },

  legendAmount: {
    fontSize: 13,
    fontWeight: "600",
  },

  legendPercent: {
    fontSize: 11,
    color: "#777",
  },

  transactionCard: {
    backgroundColor: "#ffffff",
    marginTop: 25,
    padding: 20,
    borderRadius: 25,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 6,
  },

  transactionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 15,
  },

  transactionTitle: {
    fontSize: 16,
    fontWeight: "600",
  },

  viewAll: {
    fontSize: 13,
    color: "#6a5cff",
    fontWeight: "500",
  },

  transactionRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
  },

  iconCircle: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "#f2f2f5",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },

  transactionInfo: {
    flex: 1,
  },

  transactionName: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: 4,
  },

  metaRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  badge: {
    backgroundColor: "#f2f2f5",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    marginRight: 8,
  },

  badgeText: {
    fontSize: 11,
    color: "#555",
  },

  dateText: {
    fontSize: 11,
    color: "#888",
  },

  amountText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#ff3b30",
  },

  emptyState: {
    alignItems: "center",
    paddingVertical: 20,
  },

  emptyText: {
    fontSize: 14,
    color: "#777",
  },

});
