import { Ionicons } from "@expo/vector-icons";
import { Tabs, usePathname, useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { Animated, StyleSheet, Text, TouchableOpacity } from "react-native";

export const navVisibility = new Animated.Value(0);

function CustomTabBar() {
  const router = useRouter();
  const pathname = usePathname();
  const translateY = useRef(new Animated.Value(0)).current;

  const [visible, setVisible] = useState(true);
  const hideTimerRef = useRef<NodeJS.Timeout | null>(null);

  const hideNav = () => {
    // Clear any existing timer
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
    
    Animated.timing(translateY, {
      toValue: 120,
      duration: 400,
      useNativeDriver: true,
    }).start(() => setVisible(false));
  };

  const showNav = () => {
    setVisible(true);
    Animated.timing(translateY, {
      toValue: 0,
      duration: 400,
      useNativeDriver: true,
    }).start();
    
    // Auto hide again after 2 seconds
    hideTimerRef.current = setTimeout(() => {
      hideNav();
    }, 2000);
  };

  // Initial auto hide after 2 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      hideNav();
    }, 2000);

    return () => {
      clearTimeout(timer);
      if (hideTimerRef.current) {
        clearTimeout(hideTimerRef.current);
      }
    };
  }, []);

  // Listen to scroll trigger
  useEffect(() => {
    const listener = navVisibility.addListener(({ value }) => {
      if (value > 50) {
        showNav();
      }
    });

    return () => navVisibility.removeListener(listener);
  }, []);

  const tabs = [
    { name: "/", label: "Home", icon: "home-outline" },
    { name: "/add", label: "Add", icon: "add" },
    { name: "/analytics", label: "Analytics", icon: "bar-chart-outline" },
    { name: "/search", label: "Search", icon: "search-outline" },
    { name: "/settings", label: "Settings", icon: "settings-outline" },
  ];

  return (
    <Animated.View style={[styles.container, { transform: [{ translateY }] }]}>
      {tabs.map((tab, index) => {
        const isActive = pathname === tab.name;

        return (
          <TouchableOpacity
            key={index}
            style={styles.tabItem}
            onPress={() => router.push(tab.name)}
          >
            <Ionicons
              name={tab.icon}
              size={22}
              color={isActive ? "#6a5cff" : "#777"}
            />
            <Text style={[styles.label, isActive && styles.activeLabel]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </Animated.View>
  );
}

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{ headerShown: false }}
      tabBar={() => <CustomTabBar />}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    bottom: 20,
    left: 15,
    right: 15,
    height: 75,
    backgroundColor: "#ffffff",
    borderRadius: 25,
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 10,
  },
  tabItem: {
    alignItems: "center",
  },
  label: {
    fontSize: 11,
    color: "#777",
    marginTop: 4,
  },
  activeLabel: {
    color: "#6a5cff",
    fontWeight: "600",
  },
});
