import { Ionicons } from "@expo/vector-icons";
import {
  Animated,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { navVisibility } from "./_layout";

export default function SearchScreen() {
  const results = [
    ["Starbucks Coffee", "-₹12.5", "Credit Card", "2025-01-30"],
    ["Coffee Bean & Tea", "-₹8.75", "Cash", "2025-01-29"],
    ["Local Coffee Shop", "-₹6.5", "Digital Wallet", "2025-01-28"],
    ["Dunkin' Donuts", "-₹4.99", "Credit Card", "2025-01-27"],
    ["Café Mocha", "-₹11.25", "Credit Card", "2025-01-25"],
  ];

  return (
    <View style={styles.container}>
      <Animated.ScrollView 
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: navVisibility } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >

        {/* ================= HEADER ================= */}
        <View style={styles.header}>
          <Text style={styles.title}>Search & Filter</Text>
          <Ionicons name="filter-outline" size={20} color="#333" />
        </View>

        {/* ================= SEARCH CARD ================= */}
        <View style={styles.searchCard}>

          <View style={styles.searchInput}>
            <Ionicons name="search-outline" size={18} color="#888" />
            <TextInput
              style={{ flex: 1, marginLeft: 8 }}
              value="Show coffee expenses this month"
            />
            <Ionicons name="sparkles-outline" size={18} color="#5b63ff" />
          </View>

          <Text style={styles.nlLabel}>✨ Try natural language:</Text>

          {[
            '"Transport costs over ₹50"',
            '"All food purchases last week"',
            '"Credit card expenses today"',
          ].map((item, i) => (
            <View key={i} style={styles.nlChip}>
              <Text style={styles.nlText}>{item}</Text>
            </View>
          ))}

          <View style={styles.processing}>
            <Text style={styles.processingText}>✨ AI Processing...</Text>
          </View>
        </View>

        {/* ================= QUICK FILTERS ================= */}
        <View style={styles.quickCard}>
          <Text style={styles.quickTitle}>Quick Filters</Text>

          <View style={styles.filtersRow}>
            {["This Week", "This Month", "Food", "Over ₹20"].map(
              (f, i) => (
                <TouchableOpacity
                  key={i}
                  style={[
                    styles.filterChip,
                    (f === "This Month" || f === "Food") &&
                      styles.activeFilter,
                  ]}
                >
                  <Text
                    style={[
                      styles.filterText,
                      (f === "This Month" || f === "Food") && {
                        color: "#fff",
                        fontWeight: "600",
                      },
                    ]}
                  >
                    {f}
                  </Text>
                </TouchableOpacity>
              )
            )}
          </View>
        </View>

        {/* ================= RESULTS HEADER ================= */}
        <View style={styles.resultHeader}>
          <Text style={styles.resultTitle}>8 Results</Text>
          <View style={styles.filteredTag}>
            <Text style={styles.filteredText}>Filtered</Text>
          </View>
          <Ionicons name="options-outline" size={18} color="#555" />
        </View>

        {/* ================= RESULT CARDS ================= */}
        {results.map((item, i) => (
          <View key={i} style={styles.resultCard}>

            <View style={styles.iconBox}>
              <Text style={{ fontSize: 16 }}>☕</Text>
            </View>

            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.shopName}>{item[0]}</Text>

              <View style={styles.metaRow}>
                <Text style={styles.tag}>Food</Text>
                <Text style={styles.meta}> • {item[2]}</Text>
                <Text style={styles.meta}> • {item[3]}</Text>
              </View>
            </View>

            <Text style={styles.amount}>{item[1]}</Text>
          </View>
        ))}

        {/* ================= TOTAL CARD ================= */}
        <View style={styles.totalCard}>
          <View>
            <Text style={styles.totalTitle}>Total Coffee Expenses</Text>
            <Text style={styles.totalSub}>8 transactions this month</Text>
          </View>

          <Text style={styles.totalAmount}>-₹43.99</Text>
        </View>

      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 55,
    paddingHorizontal: 14,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 14,
    alignItems: "center",
  },

  title: { fontSize: 30, fontWeight: "700" },

  searchCard: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 16,
    padding: 14,
    marginBottom: 14,
  },

  searchInput: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: "#5b63ff",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },

  nlLabel: { marginTop: 10, marginBottom: 8, color: "#555" },

  nlChip: {
    backgroundColor: "#eef4ff",
    padding: 8,
    borderRadius: 10,
    marginBottom: 8,
    alignSelf: "flex-start",
  },

  nlText: { fontSize: 12, color: "#3963ff" },

  processing: {
    marginTop: 4,
    backgroundColor: "#eef4ff",
    padding: 8,
    borderRadius: 10,
    alignSelf: "flex-start",
  },

  processingText: { color: "#3963ff", fontSize: 12 },

  quickCard: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 16,
    padding: 14,
    marginBottom: 14,
  },

  quickTitle: { fontWeight: "600", marginBottom: 10 },

  filtersRow: {
    flexDirection: "row",
    flexWrap: "wrap",
  },

  filterChip: {
    backgroundColor: "#f3f4f6",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    marginRight: 8,
    marginBottom: 8,
  },

  activeFilter: {
    backgroundColor: "#5b63ff",
  },

  filterText: { color: "#333", fontSize: 13 },

  resultHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  resultTitle: { fontWeight: "700", fontSize: 18 },

  filteredTag: {
    marginLeft: 10,
    backgroundColor: "#eef1ff",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    marginRight: "auto",
  },

  filteredText: { fontSize: 11, color: "#4f46e5" },

  resultCard: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 14,
    padding: 12,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
  },

  iconBox: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: "#fdecd2",
    justifyContent: "center",
    alignItems: "center",
  },

  shopName: { fontWeight: "600", fontSize: 16 },

  metaRow: { flexDirection: "row", marginTop: 4, alignItems: "center" },

  tag: {
    fontSize: 11,
    borderWidth: 1,
    borderColor: "#ddd",
    paddingHorizontal: 6,
    borderRadius: 6,
  },

  meta: { fontSize: 12, color: "#666" },

  amount: { fontWeight: "700", fontSize: 18 },

  totalCard: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 14,
    padding: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 120,
  },

  totalTitle: { fontWeight: "700", fontSize: 16 },
  totalSub: { color: "#666", marginTop: 4, fontSize: 12 },
  totalAmount: { fontWeight: "700", fontSize: 24 },
});
